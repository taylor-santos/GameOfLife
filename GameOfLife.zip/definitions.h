#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#define FIELD_WIDTH 18
#define FIELD_HEIGHT 16
#define BUFFER_SIZE 1024

#endif